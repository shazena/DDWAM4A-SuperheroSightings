package com.skkzas.superherosightings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperheroSightingsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SuperheroSightingsApplication.class, args);
    }

}
