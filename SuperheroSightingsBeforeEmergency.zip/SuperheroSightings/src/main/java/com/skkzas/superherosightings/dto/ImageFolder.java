package com.skkzas.superherosightings.dto;

/**
 *
 * @author Shazena Khan
 *
 * Date Created: Oct 10, 2020
 */
public class ImageFolder {

    private final String RESOURCE_ROOT = "C:/Users/Shazena/Documents/GITHUB/DDWAM4A-SuperheroSightings/SuperheroSightings/src/main/resources/static/";

    public String getRESOURCE_ROOT() {
        return RESOURCE_ROOT;
    }

}
