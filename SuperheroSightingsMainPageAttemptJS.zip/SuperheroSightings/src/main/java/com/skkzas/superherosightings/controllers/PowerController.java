package com.skkzas.superherosightings.controllers;

import org.springframework.stereotype.Controller;

/**
 *
 * @author Shazena Khan, Kristina Zakharova, Arfin Shah
 *
 * Date Created: Oct 4, 2020
 */
@Controller
public class PowerController {
}
