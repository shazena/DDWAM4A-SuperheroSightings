package com.skkzas.superherosightings.dto;

import java.util.ArrayList;

/**
 *
 * @author Shazena Khan
 *
 * Date Created: Oct 6, 2020
 */
public class StringListWrapper {

    private ArrayList<String> listOfStrings;

    public ArrayList<String> getListOfStrings() {
        return listOfStrings;
    }

    public void setListOfStrings(ArrayList<String> listOfStrings) {
        this.listOfStrings = listOfStrings;
    }

}
